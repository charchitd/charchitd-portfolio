import { useEffect, useRef, useState } from 'react';
import { Mail, MapPin } from 'lucide-react';

const Contact = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleEmailClick = () => {
    window.location.href = 'mailto:charchitdhawan@gmail.com';
  };

  return (
    <section
      ref={sectionRef}
      id="contact"
      className="section-pinned bg-dark flex items-center z-90"
    >
      {/* Left portrait card */}
      <div
        className={`absolute left-[6vw] top-[18vh] w-[40vw] h-[64vh] overflow-hidden border border-white/10 transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-x-0 scale-100' : 'opacity-0 -translate-x-20 scale-105'
        }`}
      >
        <img
          src="/images/closing_portrait.jpg"
          alt="Charchit Dhawan"
          className="w-full h-full object-cover image-grade"
        />
      </div>

      {/* Right content */}
      <div className="absolute left-[54vw] top-[26vh] w-[40vw]">
        {/* Headline */}
        <div
          className={`mb-8 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-20'
          }`}
        >
          <h2 className="font-display font-bold text-display-1 text-white leading-[0.92]">
            Let's
            <br />
            <span className="text-coral">connect</span>
          </h2>
        </div>

        {/* Paragraph */}
        <div
          className={`mb-10 transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
          style={{ transitionDelay: '200ms' }}
        >
          <p className="text-lg text-white/70 leading-relaxed">
            If you're working on fairness, simulation, or trustworthy AI—let's talk.
          </p>
        </div>

        {/* CTA */}
        <div
          className={`transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
          style={{ transitionDelay: '300ms' }}
        >
          <button
            onClick={handleEmailClick}
            className="btn-primary flex items-center gap-2"
          >
            Email me
            <Mail className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Micro line - bottom right */}
      <div
        className={`absolute right-[6vw] bottom-[10vh] font-mono text-xs text-white/40 flex items-center gap-2 transition-all duration-700 ${
          isVisible ? 'opacity-100' : 'opacity-0'
        }`}
        style={{ transitionDelay: '500ms' }}
      >
        <MapPin className="w-3 h-3" />
        charchitdhawan@gmail.com · London, UK
      </div>
    </section>
  );
};

export default Contact;
