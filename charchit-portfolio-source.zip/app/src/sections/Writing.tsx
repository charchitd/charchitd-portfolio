import { useEffect, useRef, useState } from 'react';
import { ArrowUpRight, Calendar, Clock } from 'lucide-react';

interface BlogPost {
  title: string;
  excerpt: string;
  date: string;
  readTime: string;
  tags: string[];
  featured?: boolean;
}

const blogPosts: BlogPost[] = [
  {
    title: 'Measuring Fairness Under Resource Constraints',
    excerpt: 'Exploring the trade-offs between fairness, accuracy, and computational efficiency in real-world ML deployments.',
    date: 'Jan 2025',
    readTime: '8 min read',
    tags: ['Fairness', 'ML Systems'],
    featured: true,
  },
  {
    title: 'Simulating Hiring Interventions with ABMs',
    excerpt: 'How agent-based modeling can help us understand and mitigate bias in recruitment processes.',
    date: 'Dec 2024',
    readTime: '12 min read',
    tags: ['ABM', 'Hiring', 'Simulation'],
  },
  {
    title: 'Reproducible LLM Evaluation Checklist',
    excerpt: 'A practical framework for conducting rigorous and reproducible evaluations of large language models.',
    date: 'Nov 2024',
    readTime: '6 min read',
    tags: ['LLM', 'Evaluation', 'Research'],
  },
  {
    title: 'The Privacy-Fairness Paradox',
    excerpt: 'Understanding the tensions between differential privacy and fairness in machine learning systems.',
    date: 'Oct 2024',
    readTime: '10 min read',
    tags: ['Privacy', 'Fairness', 'DP'],
  },
  {
    title: 'Semi-Supervised Learning for Research Discovery',
    excerpt: 'Leveraging co-training and LLMs to accelerate literature review and research classification.',
    date: 'Sep 2024',
    readTime: '7 min read',
    tags: ['NLP', 'Semi-supervised', 'Research'],
  },
  {
    title: 'Building Trustworthy AI: A Practitioner\'s Guide',
    excerpt: 'Practical steps for integrating fairness, transparency, and accountability into AI development workflows.',
    date: 'Aug 2024',
    readTime: '15 min read',
    tags: ['Trustworthy AI', 'Governance'],
  },
];

const Writing = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [visibleCards, setVisibleCards] = useState<boolean[]>(new Array(blogPosts.length).fill(false));

  useEffect(() => {
    const observers: IntersectionObserver[] = [];
    const cards = sectionRef.current?.querySelectorAll('.blog-card');
    
    cards?.forEach((card, index) => {
      const observer = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) {
            setVisibleCards(prev => {
              const newState = [...prev];
              newState[index] = true;
              return newState;
            });
            observer.disconnect();
          }
        },
        { threshold: 0.2 }
      );
      observer.observe(card);
      observers.push(observer);
    });

    return () => observers.forEach(obs => obs.disconnect());
  }, []);

  return (
    <section
      ref={sectionRef}
      id="writing"
      className="section-flowing bg-dark py-[10vh] z-80"
    >
      {/* Header */}
      <div className="px-[6vw] mb-12 scroll-animate">
        <h2 className="font-display font-bold text-display-3 text-white">
          Writing
        </h2>
        <p className="mt-4 text-white/60 max-w-xl">
          Thoughts on responsible AI, research methodology, and the intersection of technology and society.
        </p>
      </div>

      {/* Blog grid */}
      <div className="px-[6vw] grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {blogPosts.map((post, index) => (
          <article
            key={index}
            className={`blog-card group p-6 rounded-xl border border-white/10 bg-dark-light card-hover cursor-pointer transition-all duration-700 ${
              visibleCards[index] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
            style={{ transitionDelay: `${index * 100}ms` }}
          >
            {/* Tags */}
            <div className="flex flex-wrap gap-2 mb-4">
              {post.tags.map((tag, tagIndex) => (
                <span
                  key={tagIndex}
                  className="px-2 py-1 text-xs font-mono uppercase tracking-wider bg-coral/10 text-coral rounded"
                >
                  {tag}
                </span>
              ))}
            </div>

            {/* Title */}
            <h3 className="font-display font-semibold text-lg text-white mb-3 group-hover:text-coral transition-colors line-clamp-2">
              {post.title}
            </h3>

            {/* Excerpt */}
            <p className="text-white/60 text-sm leading-relaxed mb-4 line-clamp-3">
              {post.excerpt}
            </p>

            {/* Meta */}
            <div className="flex items-center justify-between pt-4 border-t border-white/10">
              <div className="flex items-center gap-4 text-white/40 text-xs">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {post.date}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {post.readTime}
                </span>
              </div>
              <ArrowUpRight className="w-4 h-4 text-white/40 group-hover:text-coral transition-colors" />
            </div>
          </article>
        ))}
      </div>

      {/* View all link */}
      <div className="px-[6vw] mt-10 text-center">
        <button className="inline-flex items-center gap-2 text-coral font-medium hover:underline">
          View all articles
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>
    </section>
  );
};

export default Writing;
